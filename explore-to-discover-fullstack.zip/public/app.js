const $ = (selector) => document.querySelector(selector);
const destinationGrid = $('#destinationGrid');
const authModal = $('#authModal');
const dashboardModal = $('#dashboardModal');
let authMode = 'login';
let currentUser = null;

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2800);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Request failed.');
  return data;
}

function safeText(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

async function loadDestinations() {
  try {
    const { destinations } = await api('/api/destinations');
    if (!destinations.length) {
      destinationGrid.innerHTML = '<p class="muted">No destinations yet. Check back soon.</p>';
      return;
    }
    destinationGrid.innerHTML = destinations.map(item => `
      <article class="destination-card">
        <div class="destination-photo-wrap">
          <img class="destination-image" src="${safeText(item.image_url)}" alt="${safeText(item.name)}" loading="lazy">
        </div>
        <div class="destination-info">
          <p class="destination-location">${safeText(item.location)}</p>
          <h3>${safeText(item.name)}</h3>
          <p>${safeText(item.description)}</p>
          <a class="destination-link" href="#about">DISCOVER MORE ↗</a>
        </div>
      </article>`).join('');
  } catch (error) {
    destinationGrid.innerHTML = `<p class="muted">${safeText(error.message)} Please refresh the page.</p>`;
  }
}

function setAuthMode(mode) {
  authMode = mode;
  const register = mode === 'register';
  $('#authTitle').textContent = register ? 'Create your account' : 'Welcome back';
  $('#authSubtitle').textContent = register ? 'Join us and start discovering.' : 'Log in to your account.';
  $('#nameField').classList.toggle('hidden', !register);
  $('#nameField input').required = register;
  $('#authSubmit').innerHTML = register ? 'Create account <span>↗</span>' : 'Log in <span>↗</span>';
  document.querySelectorAll('.auth-tabs button').forEach(button => button.classList.toggle('active', button.dataset.mode === mode));
  $('#authMessage').textContent = '';
  $('#authMessage').classList.remove('success');
  $('#authForm').reset();
}

function openAuth(mode = 'login') {
  setAuthMode(mode);
  authModal.classList.remove('hidden');
  $('#authForm').querySelector('input:not([type=hidden])').focus();
}

function closeAuth() { authModal.classList.add('hidden'); }

async function checkSession() {
  try {
    const result = await api('/api/auth/me');
    currentUser = result.user;
    updateAccountButton();
  } catch (_) {
    currentUser = null;
    updateAccountButton();
  }
}

function updateAccountButton() {
  $('#accountButton').textContent = currentUser ? 'My account' : 'Log in';
  $('#navSignup').classList.toggle('hidden', Boolean(currentUser));
  $('#bottomSignup').textContent = currentUser ? 'View my account' : 'Create an account ↗';
}

async function openDashboard() {
  if (!currentUser) return openAuth('login');
  $('#dashboardTitle').textContent = `Hello, ${currentUser.name}`;
  $('#dashboardEmail').textContent = currentUser.email;
  $('#adminArea').classList.toggle('hidden', currentUser.role !== 'admin');
  dashboardModal.classList.remove('hidden');
  if (currentUser.role === 'admin') await loadAdminDashboard();
}

async function loadAdminDashboard() {
  try {
    const data = await api('/api/admin/stats');
    $('#adminStats').innerHTML = `
      <div class="stat"><strong>${data.stats.totalUsers}</strong><span>Registered users</span></div>
      <div class="stat"><strong>${data.stats.totalAdmins}</strong><span>Administrators</span></div>
      <div class="stat"><strong>${data.stats.totalDestinations}</strong><span>Destinations</span></div>`;
    $('#latestUsers').innerHTML = data.latestUsers.map(user => `
      <tr><td>${safeText(user.name)}</td><td>${safeText(user.email)}</td><td>${safeText(user.role)}</td></tr>
    `).join('') || '<tr><td colspan="3">No users yet.</td></tr>';
    const { destinations } = await api('/api/destinations');
    $('#manageDestinations').innerHTML = destinations.map(item => `
      <div class="manage-row"><span>${safeText(item.name)} <small>— ${safeText(item.location)}</small></span>
      <button class="delete-button" data-delete="${item.id}">Delete</button></div>
    `).join('') || '<p class="muted">No destinations to manage.</p>';
  } catch (error) { showToast(error.message); }
}

$('#authForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = Object.fromEntries(form.entries());
  const message = $('#authMessage');
  const submit = $('#authSubmit');
  submit.disabled = true;
  message.textContent = 'Please wait...';
  try {
    const result = await api(`/api/auth/${authMode}`, { method: 'POST', body: JSON.stringify(payload) });
    currentUser = result.user;
    updateAccountButton();
    closeAuth();
    showToast(result.message);
    if (currentUser.role === 'admin') openDashboard();
  } catch (error) {
    message.textContent = error.message;
    message.classList.remove('success');
  } finally { submit.disabled = false; }
});

$('#destinationForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
  const message = $('#destinationMessage');
  try {
    await api('/api/destinations', { method: 'POST', body: JSON.stringify(payload) });
    event.currentTarget.reset();
    message.textContent = 'Destination added successfully.';
    message.classList.add('success');
    await loadDestinations();
    await loadAdminDashboard();
  } catch (error) {
    message.textContent = error.message;
    message.classList.remove('success');
  }
});

$('#manageDestinations').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-delete]');
  if (!button) return;
  if (!confirm('Delete this destination?')) return;
  try {
    await api(`/api/destinations/${button.dataset.delete}`, { method: 'DELETE' });
    showToast('Destination deleted.');
    await loadDestinations();
    await loadAdminDashboard();
  } catch (error) { showToast(error.message); }
});

$('#logoutButton').addEventListener('click', async () => {
  try {
    await api('/api/auth/logout', { method: 'POST', body: '{}' });
    currentUser = null;
    updateAccountButton();
    dashboardModal.classList.add('hidden');
    showToast('You have been logged out.');
  } catch (error) { showToast(error.message); }
});

$('#accountButton').addEventListener('click', () => currentUser ? openDashboard() : openAuth('login'));
$('#navSignup').addEventListener('click', () => openAuth('register'));
$('#bottomSignup').addEventListener('click', () => currentUser ? openDashboard() : openAuth('register'));
$('#closeModal').addEventListener('click', closeAuth);
$('#closeDashboard').addEventListener('click', () => dashboardModal.classList.add('hidden'));
document.querySelectorAll('.auth-tabs button').forEach(button => button.addEventListener('click', () => setAuthMode(button.dataset.mode)));
authModal.addEventListener('click', event => { if (event.target === authModal) closeAuth(); });
dashboardModal.addEventListener('click', event => { if (event.target === dashboardModal) dashboardModal.classList.add('hidden'); });
$('#menuToggle').addEventListener('click', () => $('#mainNav').classList.toggle('open'));
$('#mainNav').querySelectorAll('a').forEach(link => link.addEventListener('click', () => $('#mainNav').classList.remove('open')));
$('#year').textContent = new Date().getFullYear();

loadDestinations();
checkSession();
