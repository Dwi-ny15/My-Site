CREATE DATABASE IF NOT EXISTS explore_to_discover
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE explore_to_discover;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS destinations (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  location VARCHAR(160) NOT NULL,
  description TEXT NOT NULL,
  image_url VARCHAR(500) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO destinations (name, location, description, image_url)
SELECT 'Chocolate Hills', 'Bohol, Philippines',
       'Discover the iconic rolling hills and the beautiful countryside of Bohol.',
       'https://images.unsplash.com/photo-1518509562904-e7ef99cdcc86?auto=format&fit=crop&w=1200&q=85'
WHERE NOT EXISTS (SELECT 1 FROM destinations WHERE name = 'Chocolate Hills');

INSERT INTO destinations (name, location, description, image_url)
SELECT 'White Beach', 'Boracay, Philippines',
       'Enjoy soft white sand, clear water, and unforgettable island sunsets.',
       'https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?auto=format&fit=crop&w=1200&q=85'
WHERE NOT EXISTS (SELECT 1 FROM destinations WHERE name = 'White Beach');

INSERT INTO destinations (name, location, description, image_url)
SELECT 'El Nido', 'Palawan, Philippines',
       'Explore dramatic limestone cliffs, hidden lagoons, and turquoise seas.',
       'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=85'
WHERE NOT EXISTS (SELECT 1 FROM destinations WHERE name = 'El Nido');
