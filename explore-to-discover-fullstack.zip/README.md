# Explore to Discover — Full-stack travel website

A responsive travel website built with HTML, CSS, vanilla JavaScript, Node.js, Express, and MySQL.

## Features

- Responsive modern/minimalist travel landing page
- Destination cards loaded from MySQL through an Express API
- User registration and login
- Password hashing with bcrypt
- JWT authentication stored in an HTTP-only cookie
- Role-protected administrator dashboard
- Admin statistics and latest registered users
- Admin can add and delete destinations
- SQL database schema and starter destinations

## Requirements

- Node.js 18 or newer
- MySQL 8 (or a compatible MySQL server)
- npm

## 1. Create the database

Start your MySQL server. Open MySQL Workbench or a MySQL terminal and run the contents of `database.sql`.

Example terminal command:

```bash
mysql -u root -p < database.sql
```

The script creates the `explore_to_discover` database, tables, and three starter destinations.

## 2. Configure environment variables

Copy `.env.example` to a new file named `.env` in the project root.

```bash
cp .env.example .env
```

On Windows, you can copy the file manually. Edit `.env` and enter your MySQL password. Set `JWT_SECRET` to a long, random secret (at least 32 characters). Change the default admin email and password before creating the admin account.

## 3. Install dependencies

From the project folder, run:

```bash
npm install
```

## 4. Create the administrator account

After editing `.env`, run:

```bash
npm run create-admin
```

The script creates or updates the admin account using `ADMIN_NAME`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` from `.env`. Keep these credentials private. Do not use the example password on a public server.

## 5. Start the website

```bash
npm start
```

For development with automatic restarts:

```bash
npm run dev
```

Open **http://localhost:3000** in your browser.

## Project structure

```text
explore-to-discover/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── scripts/
│   └── create-admin.js
├── src/
│   ├── db.js
│   ├── middleware/
│   │   └── auth.js
│   └── routes/
│       ├── auth.js
│       ├── destinations.js
│       └── admin.js
├── database.sql
├── .env.example
├── .gitignore
├── package.json
├── server.js
└── README.md
```

## API endpoints

| Method | Endpoint | Purpose | Access |
|---|---|---|---|
| POST | `/api/auth/register` | Create a user account | Public |
| POST | `/api/auth/login` | Log in | Public |
| POST | `/api/auth/logout` | Log out | Public |
| GET | `/api/auth/me` | Get current user | Logged in |
| GET | `/api/destinations` | List destinations | Public |
| POST | `/api/destinations` | Add destination | Admin |
| DELETE | `/api/destinations/:id` | Delete destination | Admin |
| GET | `/api/admin/stats` | Dashboard statistics | Admin |
| GET | `/api/admin/users` | List users | Admin |

## How to use the admin dashboard

1. Run `npm run create-admin` to create your admin account.
2. Start the server and open the website.
3. Log in using the admin email and password from `.env`.
4. Open **My account** to see the admin dashboard.
5. Add destinations using the form, or delete an existing destination.

Regular users can register and log in, but cannot access admin endpoints.

## Important deployment/security notes

This is a learning/development starter project. Before deploying publicly:

- Use HTTPS so secure cookies can be enabled (`NODE_ENV=production`).
- Use a strong, private `JWT_SECRET` and unique database credentials.
- Change the sample admin credentials and never commit `.env`.
- Add rate limiting, CSRF protection appropriate to your deployment, stricter input validation, logging, backups, and monitoring.
- Consider pagination for the admin user list and image upload storage for a production site.
- The destination photos use remote Unsplash image URLs and require an internet connection.
