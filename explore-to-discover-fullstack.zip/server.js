require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');
const pool = require('./src/db');

const app = express();
const PORT = Number(process.env.PORT || 3000);

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('Please set JWT_SECRET in .env to a random value at least 32 characters long.');
  process.exit(1);
}

app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/destinations', require('./src/routes/destinations'));
app.use('/api/admin', require('./src/routes/admin'));

app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((error, _req, res, _next) => {
  console.error(error);
  if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ message: 'That record already exists.' });
  res.status(500).json({ message: 'Something went wrong. Please try again later.' });
});

async function start() {
  try {
    await pool.query('SELECT 1');
    app.listen(PORT, () => console.log(`Explore to Discover is running at http://localhost:${PORT}`));
  } catch (error) {
    console.error('Could not connect to MySQL. Check your .env settings and database.sql.', error.message);
    process.exit(1);
  }
}
start();
