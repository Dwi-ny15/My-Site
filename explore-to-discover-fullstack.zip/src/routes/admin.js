const express = require('express');
const pool = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate, requireAdmin);

router.get('/stats', async (_req, res, next) => {
  try {
    const [[users]] = await pool.query('SELECT COUNT(*) AS totalUsers FROM users WHERE role = "user"');
    const [[admins]] = await pool.query('SELECT COUNT(*) AS totalAdmins FROM users WHERE role = "admin"');
    const [[destinations]] = await pool.query('SELECT COUNT(*) AS totalDestinations FROM destinations');
    const [latestUsers] = await pool.query(
      'SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 8'
    );
    res.json({ stats: { ...users, ...admins, ...destinations }, latestUsers });
  } catch (error) { next(error); }
});

router.get('/users', async (_req, res, next) => {
  try {
    const [users] = await pool.query(
      'SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC'
    );
    res.json({ users });
  } catch (error) { next(error); }
});

module.exports = router;
