const express = require('express');
const pool = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.get('/', async (_req, res, next) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, name, location, description, image_url, created_at FROM destinations ORDER BY created_at DESC'
    );
    res.json({ destinations: rows });
  } catch (error) { next(error); }
});

router.post('/', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const { name, location, description, image_url } = req.body;
    if (![name, location, description, image_url].every(v => typeof v === 'string' && v.trim())) {
      return res.status(400).json({ message: 'Please complete all destination fields.' });
    }
    if (!/^https?:\/\//i.test(image_url.trim())) {
      return res.status(400).json({ message: 'Image URL must start with http:// or https://.' });
    }
    const [result] = await pool.execute(
      'INSERT INTO destinations (name, location, description, image_url) VALUES (?, ?, ?, ?)',
      [name.trim(), location.trim(), description.trim(), image_url.trim()]
    );
    res.status(201).json({
      message: 'Destination added.',
      destination: { id: result.insertId, name, location, description, image_url }
    });
  } catch (error) { next(error); }
});

router.delete('/:id', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const [result] = await pool.execute('DELETE FROM destinations WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ message: 'Destination not found.' });
    res.json({ message: 'Destination deleted.' });
  } catch (error) { next(error); }
});

module.exports = router;
